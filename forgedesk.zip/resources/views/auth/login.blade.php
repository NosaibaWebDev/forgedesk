<!DOCTYPE html>
<html lang="he" dir="rtl" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>התחברות - ForgeDesk Studio</title>
    <link rel="stylesheet" href="/css/app.css">
    <script>
        (function() {
            var saved = localStorage.getItem('theme');
            if (saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                document.documentElement.setAttribute('data-theme', 'dark');
            }
        })();
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: ['selector', '[data-theme="dark"]'],
            theme: {
                extend: {
                    colors: {
                        accent: { DEFAULT: '#17C3B2', dark: '#12A899', light: '#E8FAF8' },
                        surface: '#F7F9FC',
                        border: '#E5E7EB',
                        ink: { DEFAULT: '#111827', secondary: '#4B5563', muted: '#9CA3AF' },
                        danger: '#EF4444',
                    },
                    borderRadius: { card: '20px', btn: '12px', input: '12px', badge: '9999px' },
                    boxShadow: { card: '0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)' },
                }
            }
        }
    </script>
</head>
<body class="min-h-screen flex items-center justify-center font-sans antialiased transition-colors" style="background:var(--color-surface); color:var(--color-ink);">
    <div class="w-full max-w-md px-4">
        <div class="rounded-card border shadow-card p-8 transition-colors" style="background:var(--color-card); border-color:var(--color-border);">
            <div class="text-center mb-8">
                <div class="w-12 h-12 rounded-card flex items-center justify-center mx-auto mb-4" style="background:var(--color-accent-light);">
                    <i data-lucide="hexagon" class="w-6 h-6 text-accent"></i>
                </div>
                <h1 class="text-2xl font-bold" style="color:var(--color-ink);">ForgeDesk Studio</h1>
                <p class="mt-1.5 text-sm" style="color:var(--color-ink-secondary);">התחברות למערכת</p>
            </div>

            @if($errors->any())
                <div class="border px-4 py-3 rounded-input mb-6" style="background:rgba(239,68,68,.08); border-color:rgba(239,68,68,.2); color:var(--color-danger);">
                    <ul class="list-disc list-inside space-y-1">
                        @foreach($errors->all() as $error)
                            <li class="text-sm">{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @if(session('error'))
                <div class="border px-4 py-3 rounded-input mb-6" style="background:rgba(239,68,68,.08); border-color:rgba(239,68,68,.2); color:var(--color-danger);">
                    <p class="text-sm">{{ session('error') }}</p>
                </div>
            @endif

            <form method="POST" action="{{ route('login') }}">
                @csrf

                <div class="mb-5">
                    <label for="email" class="label">דוא"ל</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="{{ old('email') }}"
                        required
                        autofocus
                        class="input text-right"
                        placeholder="example@email.com"
                    >
                </div>

                <div class="mb-6">
                    <label for="password" class="label">סיסמה</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        required
                        class="input text-right"
                        placeholder="הקלידו את הסיסמה"
                    >
                </div>

                <div class="flex items-center justify-between mb-6">
                    <label class="flex items-center cursor-pointer">
                        <input
                            type="checkbox"
                            name="remember"
                            class="w-4 h-4 text-accent rounded focus:ring-accent/30"
                        >
                        <span class="mr-2 text-sm" style="color:var(--color-ink-secondary);">זכור אותי</span>
                    </label>
                </div>

                <button
                    type="submit"
                    class="w-full btn-primary justify-center"
                >
                    התחבר
                </button>
            </form>

            <div class="mt-6 flex justify-center">
                <button onclick="toggleTheme()" class="flex items-center gap-2 text-sm transition" style="color:var(--color-ink-muted);">
                    <i data-lucide="moon" class="w-4 h-4 dark:hidden"></i>
                    <i data-lucide="sun" class="w-4 h-4 hidden dark:block"></i>
                    <span class="dark:hidden">מצב כהה</span>
                    <span class="hidden dark:block">מצב בהיר</span>
                </button>
            </div>
        </div>

        <p class="text-center text-sm mt-6" style="color:var(--color-ink-muted);">
            &copy; {{ date('Y') }} ForgeDesk Studio. כל הזכויות שמורות.
        </p>
    </div>

    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
    <script>
        function toggleTheme() {
            var html = document.documentElement;
            var current = html.getAttribute('data-theme');
            var next = current === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', next);
            localStorage.setItem('theme', next);
        }
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof lucide !== 'undefined') lucide.createIcons();
        });
    </script>
</body>
</html>
